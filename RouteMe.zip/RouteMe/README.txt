To run the application on Windows run RouteMe.exe

To run the application on any Operating System, run RouteMe.jar
This requires Java 1.8 and the JRE or JDK.